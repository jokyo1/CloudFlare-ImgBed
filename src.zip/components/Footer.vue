<template>
    <div class="page-footer">
        <p>© 2024 Designed by <a class="footer-name" href="https://github.com/MarSeventh" target="_blank">SanyueQi</a> for You!</p>
    </div>
</template>

<style scoped>
.page-footer {
   position: fixed;
   bottom: 0;
   display: flex;
    justify-content: center;
    align-items: center;
    width: 100vw;
    color: aliceblue;
    font-size: large;
    user-select: none;
}
.footer-name {
    color: antiquewhite;
    font-weight: bold;
    text-decoration: none;
}
</style>